import time
from datetime import datetime

from flask import request, session, render_template, Blueprint

from app import app
from app.models.Task import RaidTask
from app.models.User import User
from app.models.UserOrder import UserOrder
from app.models.WeChatTicket import WeChatTicket
from app.models.errors import *
from app.utils.RespTools import setErrorData
from app.utils.wechat_login_auth import Login_auth
from app.utils.wechat_pay import Pay
from app.utils.wechat_time_tools import time_comparison, fen_to_yuan

config = app.config
bp = Blueprint('task', __name__, url_prefix="/")

app_id = config.get('WECHAT_APPID')
app_secret = config.get('WECHAT_SECRET')
mch_id = config.get('WECHAT_MCH_ID')
mch_key = config.get('WECHAT_MCH_KEY')
wechat_root = config.get('WECHAT_ROOT')
notify_url = wechat_root + '/get_notifyurl'
server_url = wechat_root + '/server'
wx_login_auth = Login_auth(app_id, app_secret)
wx_pay = Pay(app_id, mch_id, mch_key, notify_url)


@bp.route("/task_list")
def task_list():
    tasks = RaidTask.objects()
    return render_template("task_list.html", tasks=tasks)


@bp.route("/task_info/<id>")
def task_info(id):
    task = RaidTask.objects(id=id).first()
    return render_template("task_info.html", task=task)

@bp.route("/join", methods=["GET", "POST"])
def join():
    openid = get_open_id()
    if not openid:
        return setErrorData(OPENID_NOT_PASS)
    user = User.objects(wechat_openid=openid).first()

    user.name = request.form.get('name')
    user.phone = request.form.get('phone')
    province = request.form.get('province')
    if not province:
        province = ''
    city = request.form.get('city')
    if not city:
        city = ''
    area = request.form.get('area')
    if not area:
        area = ''
    address = request.form.get('address')
    user.address = address
    user.province = province
    user.city = city
    user.area = area
    user.save()
    user.reload()

    #info = request.form.get('info')
    info = str(user.info)
    # 从隐藏表单里拿到body 和 fee
    body = request.form.get("usebody")
    total_fee = request.form.get("usefee")
    # 测试价格为0.01
    if config.get('TESTING'):
        total_fee = 0.01
    elif config.get('TEST_LIST') and (openid in config.get('TEST_LIST')):
        total_fee = 0.01

    if body is None:
        return setErrorData(BODY_AND_FEE_NOT_FOUND)
    if total_fee is None:
        return setErrorData(BODY_AND_FEE_NOT_FOUND)

    # 把价格从分转换成元(经过算法，把str价格分*100再变成str价格元)
    total_fee_yuan = fen_to_yuan(total_fee)

    # 检查一下基础access_token是否过期 调用微信工具时间对比方法
    wct = WeChatTicket.objects().first()
    if not wct:
        bs_access_token = wx_login_auth.basic_access_token()
        need_access_token = bs_access_token.access_token
        ticket_data = wx_login_auth.get_jsapi_ticket(need_access_token)
        need_ticket = ticket_data.ticket
        if not need_ticket:
            return setErrorData(NO_TICKET)
        wct2 = WeChatTicket()
        wct2.access_token = need_access_token
        wct2.ticket = need_ticket
        wct2.write_time = time.time()
        wct2.name = "测试"
        wct2.save()
        # 微信JS授权要的就有signature，所以这里命名为signature
        signature_dict = wx_pay.jsapi_ticket(need_ticket)
        if not signature_dict:
            return setErrorData(NO_CONFIG_TICKET_DICT)
    else:
        # 判断要不要更新
        begin_time = wct.write_time
        d2 = begin_time
        mydelta = time_comparison(d2)
        # 要更新
        if (mydelta >= 7200):
            bs_access_token = wx_login_auth.basic_access_token()
            need_access_token = bs_access_token.access_token
            ticket_data = wx_login_auth.get_jsapi_ticket(need_access_token)
            need_ticket = ticket_data.ticket
            if not need_ticket:
                return setErrorData(NO_TICKET)
            wct.access_token = need_access_token
            wct.ticket = need_ticket
            wct.write_time = time.time()
            # 微信JS授权要的就有signature，所以这里命名为signature
            signature_dict = wx_pay.jsapi_ticket(need_ticket)
            wct.save()
        else:
            need_ticket = wct.ticket
            # 微信JS授权要的就有signature，所以这里命名为signature
            signature_dict = wx_pay.jsapi_ticket(need_ticket)
            if not signature_dict:
                return setErrorData(NO_CONFIG_TICKET_DICT)

    # 使用JSAPI方式
    # body， openid, total_fee, out_trade_no这几个参数需要传进去  notify_url开始就设为常量
    # 测试的话写死fee为1分钱，土豪请无视    body = "支付测试，这个URL设置为无参数了"    total_fee = str(1)
    out_trade_no = wx_pay.creat_out_order_no()
    data = {"body": body,
            "openid": openid,
            "total_fee": total_fee_yuan,
            "notify_url": notify_url,
            "out_trade_no": out_trade_no
            }
    # 生成了调用jsapi必须的数据字典
    jsapi_dict = wx_pay.jsapi(**data)

    # 统一下单应该成功，才开始录入订单信息，方便订单查询
    # 所以 result_code(业务结果)和return_code('返回状态码')应该都是success，不用录入数据库
    order = UserOrder()
    # 所以先不加openid到数据库
    # order.openid = openid
    order.phone_num = user.phone
    order.address = province + city + area + address
    order.nickname = user.name
    order.body = body
    order.total_fee = float(total_fee)
    order.out_trade_no = out_trade_no
    order.ischeck = "未支付"
    order.status = "不配送"
    order.create_time = datetime.now
    order.info = info

    order.prod_name = request.values.get('prod_name')
    order.prod_type = request.values.get('prod_type')
    order.test_type = request.values.get('test_type')
    order.post_type = request.values.get('post_type')
    order.send_note = request.values.get('send_note')

    order.credit = request.values.get('credit')
    if user.referee:
        order.did = user.referee

    # 保存订单
    order.save()

    order_number = out_trade_no
    if not order_number:
        return setErrorData(CODE_NOT_FOUND)
    return render_template("wechat_pay.html", jsapi_dict=jsapi_dict, signature_dict=signature_dict,
                           order_number=order_number)


def get_open_id():
    if config.get('DEV_ID'):
        openid = config.get('DEV_ID')
    else:
        openid = session.get('openid')
        #if not openid:
        #   openid = "oG3Hyvw2LlpuWKkHYXZ73oOa3wsYß"
    return openid
