# -*- coding: utf-8 -*-
import json
import time
import os
from datetime import datetime, timedelta

from flask import request, redirect, session, render_template, make_response, Blueprint
from flask import send_from_directory

from app import app
from app.models.Task import RaidTask
from app.models.User import User
from app.models.UserOrder import UserOrder
from app.models.WeChatTicket import WeChatTicket
from app.models.errors import *
from app.utils.RespTools import setErrorData, arrayToXml
from app.utils.wechat_login_auth import Login_auth
from app.utils.wechat_pay import Pay
from app.utils.wechat_time_tools import time_comparison, fen_to_yuan

config = app.config

bp = Blueprint('wechat', __name__, url_prefix="/wechat")

app_id = config.get('WECHAT_APPID')
app_secret = config.get('WECHAT_SECRET')
mch_id = config.get('WECHAT_MCH_ID')
mch_key = config.get('WECHAT_MCH_KEY')
wechat_root = config.get('WECHAT_ROOT')
notify_url = wechat_root + '/get_notifyurl'
server_url = wechat_root + '/server'
wx_login_auth = Login_auth(app_id, app_secret)
wx_pay = Pay(app_id, mch_id, mch_key, notify_url)

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET


# 发送mp文件夹里的文件
@bp.route('/<filename>')
def send_mp(filename):
    return send_from_directory(os.path.join(app.root_path, 'mp'), filename)


@bp.route("/home")
def home():
    return render_template("wechat_index.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    # url_for似乎不能用，微信会报redirect_url参数错误
    # callbackurl = url_for("authorized", _external=True )
    # url = wx_login_auth.authorize("http://wechatpay.uimix.com/wechat/authorized", "snsapi_userinfo")
    url = wx_login_auth.authorize(config.get('WECHAT_AUTH_URL') + '?redirect_uri=' + server_url, "snsapi_base")
    # 执行完wx_login_auth.authorize()最后返回了一个微信请求带有参数的URL ，直接重定向到这个URL
    print(url)
    return redirect(url)
    # 会显示出微信自己的授权界面，用户点击确定后会跳转到callbackurl那个地址


# 授权完成到这个地址，因此对这个地址上的参数进行解析，得到我们要的code，再换取access_token凭证
@bp.route("/authorized", methods=["GET", "POST"])
def authorized():
    print("#####")
    # #得到了code
    code = request.args.get("code")
    if not code:
        return setErrorData(CODE_NOT_FOUND)
    # 用code换取需要的access_token
    data = wx_login_auth.get_access_token(code)
    # 调用上面方法，从返回的json数据里得到 对应数据 openid
    openid = data.openid
    refresh_token = data.refresh_token
    access_token = data.access_token
    if not openid:
        return setErrorData(OPENID_NOT_FOUND)
    if not access_token:
        return setErrorData(ATOKEN_NOT_FOUND)
    redirect_uri = request.args.get("redirect_uri")
    state = request.args.get("state")
    if redirect_uri:
        url = redirect_uri
        session['openid'] = openid
        return redirect(url)
    else:
        resp = make_response(render_template("wechat_auth_success.html", all_data=data))
        return resp


@bp.route("/server", methods=["GET", "POST"])
def server():
    openid = get_open_id()
    # if not openid:
    #     # return setErrorData(OPENID_NOT_PASS)
    #     rd = wechat_root + '/server'
    #     url = wx_login_auth.authorize(config.get('WECHAT_AUTH_URL') + '?redirect_uri=' + rd, "snsapi_base")
    #     return redirect(url)
    products = Product.objects(hide__ne=True)
    expires = datetime.now() + timedelta(days=1)
    resp2 = make_response(render_template("wechat_server.html", products=products))
    resp2.set_cookie("openid", openid, expires=expires)
    return resp2


@bp.route("/task_pay", methods=["GET", "POST"])
def task_pay():
    openid = get_open_id()
    if not openid:
        # return setErrorData(OPENID_NOT_PASS)
        rd = wechat_root + '/task_pay'
        url = wx_login_auth.authorize(config.get('WECHAT_AUTH_URL') + '?redirect_uri=' + rd, "snsapi_base")
        print(url)
        return redirect(url)

    user = User.objects(wechat_openid=openid).first()

    task_id = request.form.get('task_id')
    task = RaidTask.objects(id=task_id).first()

    body = task.name
    total_fee = task.deposit
    # 测试价格为0.01
    if config.get('TESTING'):
        total_fee = 0.01
    elif config.get('TEST_LIST') and (openid in config.get('TEST_LIST')):
        total_fee = 0.01

    if total_fee is None:
        return setErrorData(BODY_AND_FEE_NOT_FOUND)

    # 把价格从分转换成元(经过算法，把str价格分*100再变成str价格元)
    total_fee_yuan = fen_to_yuan(total_fee)

    # 检查一下基础access_token是否过期 调用微信工具时间对比方法
    wct = WeChatTicket.objects().first()
    if not wct:
        bs_access_token = wx_login_auth.basic_access_token()
        need_access_token = bs_access_token.access_token
        ticket_data = wx_login_auth.get_jsapi_ticket(need_access_token)
        need_ticket = ticket_data.ticket
        if not need_ticket:
            return setErrorData(NO_TICKET)
        wct2 = WeChatTicket()
        wct2.access_token = need_access_token
        wct2.ticket = need_ticket
        wct2.write_time = time.time()
        wct2.name = "测试"
        wct2.save()
        # 微信JS授权要的就有signature，所以这里命名为signature
        signature_dict = wx_pay.jsapi_ticket(need_ticket)
        if not signature_dict:
            return setErrorData(NO_CONFIG_TICKET_DICT)
    else:
        # 判断要不要更新
        begin_time = wct.write_time
        d2 = begin_time
        mydelta = time_comparison(d2)
        # 要更新
        if (mydelta >= 7200):
            bs_access_token = wx_login_auth.basic_access_token()
            need_access_token = bs_access_token.access_token
            ticket_data = wx_login_auth.get_jsapi_ticket(need_access_token)
            need_ticket = ticket_data.ticket
            if not need_ticket:
                return setErrorData(NO_TICKET)
            wct.access_token = need_access_token
            wct.ticket = need_ticket
            wct.write_time = time.time()
            # 微信JS授权要的就有signature，所以这里命名为signature
            signature_dict = wx_pay.jsapi_ticket(need_ticket)
            wct.save()
        else:
            need_ticket = wct.ticket
            # 微信JS授权要的就有signature，所以这里命名为signature
            signature_dict = wx_pay.jsapi_ticket(need_ticket)
            if not signature_dict:
                return setErrorData(NO_CONFIG_TICKET_DICT)

    # 使用JSAPI方式
    # body， openid, total_fee, out_trade_no这几个参数需要传进去  notify_url开始就设为常量
    # 测试的话写死fee为1分钱，土豪请无视    body = "支付测试，这个URL设置为无参数了"    total_fee = str(1)
    out_trade_no = wx_pay.creat_out_order_no()
    data = {"body": body,
            "openid": openid,
            "total_fee": total_fee_yuan,
            "notify_url": notify_url,
            "out_trade_no": out_trade_no
            }
    # 生成了调用jsapi必须的数据字典
    jsapi_dict = wx_pay.jsapi(**data)

    # 统一下单应该成功，才开始录入订单信息，方便订单查询
    # 所以 result_code(业务结果)和return_code('返回状态码')应该都是success，不用录入数据库
    order = UserOrder()
    # 所以先不加openid到数据库
    # order.openid = openid

    order.body = body
    order.total_fee = float(total_fee)
    order.out_trade_no = out_trade_no
    order.status = "支付中"
    order.create_time = datetime.now

    # 保存订单
    order.save()

    order_number = out_trade_no
    if not order_number:
        return setErrorData(CODE_NOT_FOUND)

    success_url=request.form.get('success_url')
    return render_template("wechat_pay.html", jsapi_dict=jsapi_dict, signature_dict=signature_dict,
                           order_number=order_number, success_url=success_url)


@bp.route("/get_notifyurl", methods=["GET", "POST"])
def get_notifyurl():
    allthings = request.stream.read()
    if not allthings:
        return setErrorData(XML_NOT_FOUND)
    allthings_dict = ET.fromstring(allthings)
    return_code = allthings_dict.find('return_code').text
    if return_code != 'SUCCESS':
        return setErrorData(XML_NOT_FOUND)
    o_t_n = allthings_dict.find('out_trade_no').text
    data = {"out_trade_no": o_t_n}
    result_dict = wx_pay.order_query(**data)

    # 得到了 查询返回的数据dict,把需要的数据展示出来，给用户看就行。下面必须判断result_code，方便把数据库里的信息修改
    if result_dict.result_code == "FAIL":
        return setErrorData(ORDER_NOT_FOUND)

    out_trade_no = result_dict.out_trade_no
    userorder = UserOrder.objects(out_trade_no=out_trade_no).first()
    userorder.ischeck = "已支付"
    userorder.status = "已支付"
    userorder.openid = result_dict.openid
    userorder.save()

    respData = {'return_code': "SUCCESS"}
    respData = arrayToXml(respData)
    return respData


@bp.route("/check_order", methods=["GET", "POST"])
def show_order():
    # 向用户展示订单之前，商户要先自己再查询一下，到底订单有没有生成，是不是这个订单，双重查询保证一下，不写这个也行
    o_t_n = request.args.get("order_number")
    data = {"out_trade_no": o_t_n}
    result_dict = wx_pay.order_query(**data)

    # 得到了 查询返回的数据dict,把需要的数据展示出来，给用户看就行。下面必须判断result_code，方便把数据库里的信息修改
    if result_dict.result_code == "FAIL":
        return setErrorData(ORDER_NOT_FOUND)

    out_trade_no = result_dict.out_trade_no
    userorder = UserOrder.objects(out_trade_no=out_trade_no).first()
    userorder.ischeck = "已支付"
    if userorder.post_type == "邮寄":
        userorder.status = "待配送"
    elif userorder.post_type == "送检":
        userorder.status = "送检中"
    userorder.openid = result_dict.openid
    userorder.save()
    # 增加医生积分
    user = User.objects(wechat_openid=userorder.openid).first()
    if user:
        if user.referee and not userorder.credit_paid:
            doctor = Doctor.objects(pk=user.referee).first()
            print(user.referee)
            if doctor:
                print(doctor.credit)
                doctor.credit = doctor.credit + userorder.credit
                doctor.save()
                userorder.credit_paid = True
                userorder.save()

    if not userorder.informed:
        if userorder.post_type == '送检':
            post = {
                "touser": userorder.openid,
                "template_id": "G7L9ezj6FX6_h__AKyUhK-qyYE4qbRGkj96JKrVjxsU",
                "url": config.get('SITE_ROOT') + 'wechat/send_note/' + str(userorder.out_trade_no),
                "data": {
                    "first": {
                        "value": "您的订单已经支付成功！"
                    },
                    "keyword1": {
                        "value": userorder.out_trade_no
                    },
                    "keyword2": {
                        "value": userorder.prod_name
                    },
                    "keyword3": {
                        "value": str(userorder.total_fee)
                    },
                    "remark": {
                        "value": "请点击“详情”查看下一步操作"
                    }
                }
            }
            resp = wx_login_auth.send_message(post)
        else:
            post = {
                "touser": userorder.openid,
                "template_id": "G7L9ezj6FX6_h__AKyUhK-qyYE4qbRGkj96JKrVjxsU",
                "url": config.get('SITE_ROOT') + 'wechat/query_list',
                "data": {
                    "first": {
                        "value": "您的订单已经支付成功！请等待接收检测盒快递。"
                    },
                    "keyword1": {
                        "value": userorder.out_trade_no
                    },
                    "keyword2": {
                        "value": userorder.prod_name
                    },
                    "keyword3": {
                        "value": str(userorder.total_fee)
                    },
                    "remark": {
                        "value": "请点击“详情”查看您的订单"
                    }
                }
            }
            resp = wx_login_auth.send_message(post)
        userorder.informed = True
        userorder.save()

    return render_template("wechat_pay_success.html")


################这里是需要另外的服务号一个按钮栏点击打开，微信支付到上面为止已经完成了~~撒花~~~~################
# 查询订单
# @bp.route("/query_order", methods=["GET", "POST"])
# def query_order():
#     return render_template("user_to_order.html")


@bp.route("/query_order", methods=["GET", "POST"])
def query_order():
    # url = wx_login_auth.authorize("http://wechatpay.uimix.com/wechat/query_list", "snsapi_base")
    url = wx_login_auth.authorize(wechat_root + '/query_list', "snsapi_base")
    # 执行完wx_login_auth.authorize()最后返回了一个微信请求带有参数的URL ，直接重定向到这个URL
    return redirect(url)
    # 会显示出微信自己的授权界面，用户点击确定后会跳转到callbackurl那个地址


# 订单详情
@bp.route("/query_list", methods=["GET", "POST"])
def query_list():
    openid = get_open_id()
    if not openid:
        # return setErrorData(OPENID_NOT_PASS)
        rd = wechat_root + '/query_list'
        url = wx_login_auth.authorize(config.get('WECHAT_AUTH_URL') + '?redirect_uri=' + rd, "snsapi_base")
        return redirect(url)

    # 用户订单详情查询 用户信息查询
    mongo_order_dict = UserOrder.objects(openid=openid).all()
    if not mongo_order_dict:
        mongo_order_dict_gai = mongo_order_dict
        return render_template("show_order.html", mongo_order_dict_gai=mongo_order_dict_gai)

    # 要实现一些效果如：电话号码的4位要用*来表示，在HTML的页面上我不会用jinja2语法来过滤查询，只会后台传入处理过的数据
    gai_phone_47 = "****"
    gai_add_7end = "*********"
    lt = []
    for x in mongo_order_dict:
        a = x
        # 改phone号码效果
        if x.phone_num:
            gai_phone = x.phone_num
            gai_phone_13 = gai_phone[0:3]
            gai_phone_811 = gai_phone[7:]
            new_phone = gai_phone_13 + gai_phone_47 + gai_phone_811
        else:
            new_phone = ""
        # 改地址效果
        gai_add = x.address
        gai_add_16 = gai_add[0:6]
        new_add = gai_add_16 + gai_add_7end
        a.phone_num = new_phone
        a.address = new_add
        lt.append(a)
    mongo_order_dict_gai = lt
    return render_template("show_order.html", mongo_order_dict_gai=mongo_order_dict_gai)


@bp.route("/back_result", methods=["GET", "POST"])
def back_result():
    order_no = request.args.get("order_no")
    order = UserOrder.objects(out_trade_no=order_no).first()
    if not order:
        return setErrorData(ORDER_NOT_FOUND)
    result = order.result
    if result:
        return render_template("show_result.html", result=result)
    return setErrorData(RESULT_NOT_FOUND)


@bp.route("/show_order_code", methods=["GET", "POST"])
def show_order_code():
    openid = get_open_id()
    if not openid:
        # return setErrorData(OPENID_NOT_PASS)
        rd = wechat_root + '/query_list'
        url = wx_login_auth.authorize(config.get('WECHAT_AUTH_URL') + '?redirect_uri=' + rd, "snsapi_base")
        return redirect(url)

    order_no = request.args.get("order_no")
    mongo_order_dict = UserOrder.objects(out_trade_no=order_no).first()
    if not mongo_order_dict:
        return setErrorData(ORDER_NOT_FOUND)
    if mongo_order_dict.openid != openid:
        return setErrorData(NOT_AUTHORIZED)
    mongo_project_doct = Product.objects(name=mongo_order_dict.body[4:]).first()
    if not mongo_project_doct:
        return setErrorData(PROJECT_NOT_FOUND)
    type = mongo_project_doct.tubetype
    taketime = mongo_project_doct.taketime
    info = json.loads(mongo_order_dict.info.replace("'", "\""))
    name = ''
    if info.get('name'):
        name = info['name']
    if not type:
        if not taketime:
            code = {'name': name,
                    'order': '02' + mongo_order_dict.out_trade_no,
                    'project': mongo_order_dict.body[4:]}
        else:
            code = {'name': name,
                    'order': '02' + mongo_order_dict.out_trade_no,
                    'project': mongo_order_dict.body[4:],
                    'taketime': taketime}
    else:
        if not taketime:
            code = {'name': name,
                    'order': '02' + mongo_order_dict.out_trade_no,
                    'project': mongo_order_dict.body[4:],
                    'type': type}
        else:
            code = {'name': name,
                    'order': '02' + mongo_order_dict.out_trade_no,
                    'project': mongo_order_dict.body[4:],
                    'type': type, 'taketime': taketime}
    return render_template("show_order_code.html", code=json.dumps(code, ensure_ascii=False, sort_keys=True))


@bp.route("/prod_detail/<id>", methods=["GET", "POST"])
def prod_detail(id):
    # 读取推荐医生id
    did = request.values.get("did")
    if did:
        openid = get_open_id()
        if not openid:
            # 如果拿不到openid，可能是未登陆，转到登陆界面
            rd = wechat_root + '/prod_detail/%s?did=%s' % (id, did)
            url = wx_login_auth.authorize(config.get('WECHAT_AUTH_URL') + '?redirect_uri=' + rd, "snsapi_base")
            return redirect(url)

        user = User.objects(wechat_openid=openid).first()
        # 如果找不到用户，新建一个用户
        if not user:
            user = User()
            user.wechat_openid = openid
            user.save()
        user.referee = did
        user.save()
    prod = Product.objects(id=id).first()
    return render_template("prod_detail.html", x=prod)


@bp.route("/order_info/<id>", methods=["GET", "POST"])
def order_info(id):
    # 处理从订单过来的姓名、地址、联系方式等信息
    info_new = request.form.to_dict()
    print(info_new)

    openid = get_open_id()
    if not openid:
        # return setErrorData(OPENID_NOT_PASS)
        rd = '/userInfo/tp_userInfo/%s' % id
        url = wx_login_auth.authorize(config.get('WECHAT_AUTH_URL') + '?redirect_uri=' + rd, "snsapi_base")
        return redirect(url)

    user = User.objects(wechat_openid=openid).first()
    if not user:
        user = User()
        user.wechat_openid = openid
        user.save()
    info = ''
    prod = Product.objects(id=id).first()
    if user.info:
        # info = '"data":%s' % user.info
        view = '"view": {"messages": {"zh_CN": {"notOptional": ""}}}'
        info = '"data": data'
        prod_info = "{%s,%s,%s" % (view, info, prod.prod_info[1:])
    else:
        prod_info = prod.prod_info
    prod_info = prod_info.replace("order_confirm", "order_confirm/%s" % id)
    print(prod_info)
    if prod.prod_template:
        return render_template(prod.prod_template, prod=prod, info=user.info)
    else:
        return render_template("order_info.html", prod=prod, prod_info=prod_info)


@bp.route("/order_confirm/<id>", methods=["GET", "POST"])
def order_confirm(id):
    info_new = request.form.to_dict()
    openid = get_open_id()
    if not openid:
        return setErrorData(OPENID_NOT_PASS)
    user = User.objects(wechat_openid=openid).first()
    info = ''
    if user:
        info_old = user.info
        info = {**info_old, **info_new}
        user.update(set__info=info)
    else:
        user = User()
        user.wechat_openid = openid
        user.info = info_new
        user.save()

    user.reload()
    print(user.info)
    prod = Product.objects(id=id).first()

    if user.phone:
        phone = user.phone
    else:
        phone = info['mobile']

    if user.address:
        address = user.address
    else:
        address = info['address']

    if user.name:
        name = user.name
    else:
        name = info['name']

    province = ''
    city = ''
    area = ''

    if info.get('province'):
        province = info.get('province')
    elif user.province:
        province = user.province

    if info.get('city'):
        city = info.get('city')
    elif user.city:
        city = user.city

    if info.get('area'):
        area = info.get('area')
    elif user.area:
        area = user.area

    return render_template("order_confirm.html",
                           prod=prod,
                           name=name,
                           phone=phone,
                           province=province,
                           city=city,
                           area=area,
                           address=address,
                           info=info_new)


@bp.route("/user_info/", methods=["GET", "POSTn"])
def user_info():
    openid = get_open_id()
    if not openid:
        return setErrorData(OPENID_NOT_PASS)
    user = User.objects(wechat_openid=openid).first()
    if user:
        return json.dumps(user.info, ensure_ascii=False)


@bp.route("/known_issues/<id>", methods=["GET", "POST"])
def known_issues(id):
    prod = Product.objects(id=id).first()
    text = '无'
    if prod.known_issues:
        text = prod.known_issues
    return render_template("known_issues.html", text=text, name=prod.name)


@bp.route("/known_issues_patient/<id>", methods=["GET", "POST"])
def known_issues_patient(id):
    prod = Product.objects(id=id).first()
    text = '无'
    if prod.known_issues:
        text = prod.known_issues_patient
    return render_template("known_issues_patient.html", text=text, name=prod.name)


@bp.route("/send_note/<out_trade_no>", methods=["GET", "POST"])
def send_note(out_trade_no):
    order = UserOrder.objects(out_trade_no=out_trade_no).first()
    text = '无'
    if order.send_note:
        text = order.send_note
    return render_template("send_note.html", text=text, name=order.nickname)


@bp.route("/help_info/", methods=["GET", "POST"])
def help_info():
    url = 'https://mp.weixin.qq.com/s?__biz=MzUyMDgwODQ0OA==&mid=2247483727&idx=1&sn=8c428bfcb0c2ec8110d39c558b9b9a01&chksm=f9e5f020ce927936c205dd79d8f0b2f92053dac4b3575a9ea2f938c2d1e3307d17a5a6da32b2#rd'
    return redirect(url)


@bp.route("/wechat_telephone/", methods=["GET", "POST"])
def wechat_telephone():
    openid = get_open_id()
    if not openid:
        rd = '/userInfo/tp_userInfo/%s' % id
        url = wx_login_auth.authorize(config.get('WECHAT_AUTH_URL') + '?redirect_uri=' + rd, "snsapi_base")
        return redirect(url)
    if openid:
        return render_template("/wechat_telephone.html")


def get_open_id():
    if config.get('DEV_ID'):
        openid = config.get('DEV_ID')
    else:
        openid = session.get('openid')
        # if not openid:
        #   openid = "oG3Hyvw2LlpuWKkHYXZ73oOa3wsYß"
    return openid
