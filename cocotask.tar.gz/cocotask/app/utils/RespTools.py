from flask.helpers import make_response
from mongoengine import Document, DateTimeField, StringField, FloatField, IntField, ListField, EmbeddedDocumentField, \
    ReferenceField
from bson.dbref import DBRef
from flask import jsonify
import json


def arrayToXml(arr):
    xml = ["<xml>"]
    for k, v in arr.items():
        if v.isdigit():
            xml.append("<{0}>{1}</{0}>".format(k, v))
        else:
            xml.append("<{0}><![CDATA[{1}]]></{0}>".format(k, v))
    xml.append("</xml>")
    return "".join(xml)


def setRespData(respData):
    headers = {"Access-Control-Allow-Origin": "*"}
    respDataJson = jsonify(respData)
    resp = make_response(respDataJson, 200, headers)
    return resp


def setErrorData(error):
    errorcode = error[0]
    errortype = error[1]
    errormsg = error[2]

    headers = {"Access-Control-Allow-Origin": "*"}
    error = {'errorcode': errorcode,
             'errormsg': errormsg}
    respDataJson = json.dumps(error, ensure_ascii=False)
    resp = make_response(respDataJson, errortype, headers)
    return resp


def mongo_to_dict(obj, field_list=[], include_id=False):
    return_data = []

    if include_id:
        if isinstance(obj, Document):
            return_data.append(("id", str(obj.id)))

    for field_name in obj._fields:

        if field_name in ("id",):
            continue

        if field_list == [] or (field_name in field_list):
            data = obj._data[field_name]
            if data:
                if isinstance(obj._fields[field_name], DateTimeField):
                    return_data.append((field_name, str(data.isoformat())))
                elif isinstance(obj._fields[field_name], StringField):
                    return_data.append((field_name, str(data)))
                elif isinstance(obj._fields[field_name], FloatField):
                    return_data.append((field_name, float(data)))
                elif isinstance(obj._fields[field_name], IntField):
                    return_data.append((field_name, int(data)))
                elif isinstance(obj._fields[field_name], ListField):
                    if data:
                        if type(data[0]) == str:
                            return_data.append((field_name, data))
                        else:
                            rd = []
                            d = eval('obj.' + field_name)
                            for item in d:
                                rd.append(mongo_to_dict(item))
                            return_data.append((field_name, rd))
                elif isinstance(obj._fields[field_name], EmbeddedDocumentField):
                    return_data.append((field_name, mongo_to_dict(data)))
                elif isinstance(obj._fields[field_name], ReferenceField):
                    o = eval('obj.' + field_name + '.__str__()')
                    return_data.append((field_name, str(o)))

    return dict(return_data)


def mongolist_to_dict(objs, field_list=[], include_id=False):
    return_data = []
    for obj in objs:
        return_data.append(mongo_to_dict(obj, field_list, include_id))
    return return_data
