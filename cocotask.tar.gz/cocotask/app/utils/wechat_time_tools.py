# coding=utf-8
import datetime
import time

#  datetime 的方法
# def datetime_comparison(d2):
#     now = datetime.datetime.now()
#     # 补充一点： t_str = '2012-03-05 16:26:23'  字符串
#     # 将字符串转换为日期 string => datetime
#     # d = datetime.datetime.strptime(t_str, '%Y-%m-%d %H:%M:%S')
#
#     # 在datetime模块中有timedelta类，这个类的对象用于表示一个时间间隔，比如两个日#期或者时间的差别。
#     # 计算两个日期的间隔
#     delta = d2 - now
#     # 构造方法datetime.timedelta(days=0, seconds=0, microseconds=0, milliseconds=0, minutes=0, hours=0, weeks=0)
#     # 所以用 delta.days delta.microseconds delta.seconds
#     return delta

# time 的方法
def time_comparison(d2):
    d2= int(d2)
    now = int(time.time())
    delta = now - d2
    #返回相差的秒数
    return delta




def fen_to_yuan(str_price):
   float_yuan = round(float(str_price), 2)
   int_yuan = int(float_yuan*100)
   str_yuan = str(int_yuan)
   return str_yuan
