# -*- coding: utf-8 -*-
class WeixinError(Exception):
    def __init__(self, msg):
        super(WeixinError, self).__init__(msg)
