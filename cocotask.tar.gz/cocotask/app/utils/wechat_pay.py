# -*- coding: utf-8 -*-
import datetime
import time
import string
import random
import hashlib
import urllib.request
import urllib.parse
from .wechat_base import Map
from .wechat_error import WeixinError

try:
    from flask import request
except Exception:
    request = None

# try:
#     from lxml import etree
# except ImportError:
# #     from xml.etree import cElementTree as etree
# # except ImportError:
from xml.etree import ElementTree as etree

__all__ = ("PayError", "Pay")


class PayError(WeixinError):
    def __init__(self, msg):
        super(PayError, self).__init__(msg)


# 四个参数分别是公众号id ， 商户号id ， 商户密匙 ， 通知地址
class Pay():
    def __init__(self, app_id, mch_id, mch_key, notify_url):
        self.opener = urllib.request.build_opener(urllib.request.HTTPSHandler())

        self.app_id = app_id
        self.mch_id = mch_id
        self.mch_key = mch_key
        self.notify_url = notify_url
        self.pay_url = "http://api.aizhice.com/wechat/write_info"

    # @property装饰器用于将一个方法变成属性。
    # 网页（JSAPI）支付提交用户端ip，得到终端ip
    @property
    def remote_addr(self):
        if request is not None:
            return request.remote_addr
        return ""

    # 参数需要的随机字符串，不长于32位
    @property
    def creat_nonce_str(self):
        char = string.ascii_letters + string.digits
        return "".join(random.choice(char) for _ in range(16))

        # 参数需要的商户订单号，不长于32位 算法：当前时间str（16）加15位随机数
        # def creat_out_order_no(self, length=15):
        #     now = []
        #     now.append(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
        #     chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        #     strs = []
        #     for x in range(length):
        #         strs.append(chars[random.randrange(0, len(chars))])
        #     return "".join(now + strs)

    # 参数需要的商户订单号，不长于32位 算法：当前时间戳加4位随机数
    def creat_out_order_no(self, length=4):
        now = []
        now.append(str(int(time.time())))
        chars = "0123456789"
        strs = []
        for x in range(length):
            strs.append(chars[random.randrange(0, len(chars))])
        return "".join(now + strs)

    to_uft8 = lambda self, x: x.encode("utf-8") if isinstance(x, str) else x

    # 签名所有发送或者接收到的数据为集合M,将集合M内非空参数值的参数按照参数名ASCII码从小到大排序
    # URL键值对的格式（即key1 = value1 & key2 = value2…）拼接成字符串stringA
    # tringA最后拼接上key得到stringSignTemp字符串，并对stringSignTemp进行MD5运算，
    # 再将得到的字符串所有字符转换为大写
    def sign(self, raw):
        raw = [(k, str(raw[k]) if isinstance(raw[k], int) else raw[k])
               for k in sorted(raw.keys())]

        s = "&".join("=".join(kv) for kv in raw if kv[1])
        s += "&key={0}".format(self.mch_key)
        return hashlib.md5(self.to_uft8(s)).hexdigest().upper()

    def check_sign(self, data):
        sign = data.pop("sign")
        return sign == self.sign(data)

    # 生成xml格式发送
    def to_xml(self, arr):
        xml = ["<xml>"]
        for k, v in arr.items():
            if v.isdigit():
                xml.append("<{0}>{1}</{0}>".format(k, v))
            else:
                xml.append("<{0}><![CDATA[{1}]]></{0}>".format(k, v))
        xml.append("</xml>")
        return "".join(xml)

    # 每个element对象都具有以下属性：
    # 1.tag：string对象，表示数据代表的种类。
    # 2.attrib：dictionary对象，表示附有的属性。
    # 3.text：string对象，表示element的内容。
    # 4.tail：string对象，表示element闭合之后的尾迹。
    # 例如：< tag attrib1 = 1 > text < / tag > tail
    def to_dict(self, content):
        raw = {}
        root = etree.fromstring(content)
        for child in root:
            raw[child.tag] = child.text
        return raw

    # 不发送xml或json，只接受一个xml格式，并解析转成dict
    def receive_xml_to_dict(self, url):
        resp = self.opener.open(url, timeout=20)
        data = Map(self.to_dict(resp.read()))
        if data is None:
            raise PayError("没有解析到任何数据")
        return data

    # 实行发送请求，并且得到返回结果
    def pay_send_get(self, url, data):
        data = self.to_xml(data)
        req = urllib.request.Request(url, bytes(data, encoding="utf8"))
        # try:
        # resp = urllib.request.urlopen(url,bytes(data, encoding="utf8"), timeout=20)
        resp = self.opener.open(req, timeout=20)
        # # except urllib.request.HTTPSHandler as e:
        # #     resp = e
        data = Map(self.to_dict(resp.read()))

        # 微信服务器返回的xml里有:
        # 返回状态码：return_code
        # 此字段是通信标识，非交易标识，交易是否成功需要查看result_code来判断
        # 返回信息:return_msg     如果无错为空
        if data.return_code == "FAIL":
            raise PayError(data.return_msg)

        # 得到了返回的xml，并且转成dict类型
        return data

    # 统一下单(JSAPI, NATIVE, APP)但本系统决定只使用JSAPI所以固定了一些参数
    # 本系统自动配置：app_id, mch_id , nonce_str, sign, spbill_create_ip， trade_type ,notify_url
    # 自己必须填写：body， openid, total_fee, out_trade_no
    # spbill_create_ip在flask框架下可以自动填写
    # openid使用JSAPI必须填写
    def unified_order(self, **data):
        # 请求微信链接
        url = "https://api.mch.weixin.qq.com/pay/unifiedorder"

        data.setdefault("appid", self.app_id)
        data.setdefault("mch_id", self.mch_id)
        data.setdefault("trade_type", "JSAPI")
        data.setdefault("nonce_str", self.creat_nonce_str)  # 因为使用了property装饰器所以变成了self对象的属性直接.出来
        data.setdefault("notify_url", self.notify_url)
        data.setdefault("spbill_create_ip", self.remote_addr)
        data.setdefault("sign", self.sign(data))

        # 确保成功必须填写的参数
        if "out_trade_no" not in data:
            raise PayError("缺少必须的参数：trade_no,商户订单号")
        if "appid" not in data:
            raise PayError("缺少必须的参数：appid")
        if "mch_id" not in data:
            raise PayError("缺少必须的参数：mch_id")
        if "appid" not in data:
            raise PayError("缺少必须的参数：appid")
        if "body" not in data:
            raise PayError("缺少必须的参数:body,商品描述")
        if "total_fee" not in data:
            raise PayError("缺少必须的参数:total_fee,总金额")
        # 情况判断
        if data["trade_type"] == "JSAPI" and "openid" not in data:
            raise PayError("JSAPI类型缺少必须参数：openid，用户id")
        if data["trade_type"] == "NATIVE" and "product_id" not in data:
            raise PayError("NATIVE类型缺少必须参数：product_id，商品ID")

        # 完成准备开始请求啦
        raw = self.pay_send_get(url, data)
        # return_code为SUCCESS，但业务结果result_code如果为FAIL时候会有：
        # 错误代码：err_code     错误代码描述：err_code_des
        err_msg = raw.err_code_des
        if err_msg:
            raise PayError(err_msg)
        # 提示：raw已经是dict类型了，包括了微信预定单所必须的内容了,注意微信返回的sign是跟你提交的不一样的，
        # 要校验的话自己拿它返回的算个sign，对比一下一样么
        return raw

    # 预定单数据都有了，但是专门要为jsapi支付做一个让JavaScript调用的数据
    def jsapi(self, **kwargs):
        raw = self.unified_order(**kwargs)
        package = "prepay_id={0}".format(raw["prepay_id"])
        timestamp = str(int(time.time()))
        nonce_str = self.creat_nonce_str

        raw = dict(appId=self.app_id, timeStamp=timestamp, nonceStr=nonce_str,
                   package=package, signType="MD5")

        sign = self.sign(raw)
        return dict(appId=self.app_id, timeStamp=timestamp, nonceStr=nonce_str,
                    package=package, paySign=sign)

    # jsapi调用门票
    def jsapi_ticket(self, ticket):
        timestamp = str(int(time.time()))
        noncestr = self.creat_nonce_str
        data = {'jsapi_ticket': ticket, 'noncestr': noncestr, 'timeStamp': timestamp, 'url': self.pay_url}
        sha1 = hashlib.sha1()
        keys = data.keys()
        mylist = list(data.keys())
        mylist.sort()
        data_str = '&'.join(['%s=%s' % (key, data[key]) for key in mylist])
        signature = hashlib.sha1(data_str.encode('utf-8')).hexdigest()
        return dict(appId=self.app_id, timeStamp=timestamp, nonceStr=noncestr, signature=signature)


        # 支付完成之后，要对订单进行查询
        # 必须的参数是：appid ， mch_id， nonce_str， transaction_id微信订单号（商户订单号：out_trade_no可选），sign

    # out_trade_no, transaction_id至少填一个       appid, mchid, nonce_str不需要填入
    def order_query(self, **data):
        url = "https://api.mch.weixin.qq.com/pay/orderquery"
        # 判断 有没有订单号
        if "out_trade_no" not in data and "transaction_id" not in data:
            raise PayError("订单查询，out_trade_no、transaction_id至少填一个")
        data.setdefault("appid", self.app_id)
        data.setdefault("mch_id", self.mch_id)
        data.setdefault("nonce_str", self.creat_nonce_str)
        data.setdefault("sign", self.sign(data))
        return self.pay_send_get(url, data)
