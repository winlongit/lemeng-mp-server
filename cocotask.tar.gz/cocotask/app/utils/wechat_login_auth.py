# -*- coding: utf-8 -*-
import json
import urllib.request
import urllib.parse
from .wechat_error import WeixinError
from .wechat_base import Map
from app.models.WeChatTicket import WeChatTicket
from datetime import datetime
from app.utils.wechat_time_tools import time_comparison
import time

__all__ = ("Login_authError", "Login_auth")


class Login_authError(WeixinError):
    def __init__(self, msg):
        super(Login_authError, self).__init__(msg)


class Login_auth():
    def __init__(self, app_id, app_secret):
        # 创建一个自己的操作器opener 类型为HTTPSHandler
        self.opener = urllib.request.build_opener(urllib.request.HTTPSHandler)
        self.app_id = app_id
        self.app_secret = app_secret

    # 对URL地址加参数
    def add_query(self, url, args):
        # 如果没有参数就直接用这个URL
        if not args:
            return url
        return url + (' ?' in url and '&' or '?') + urllib.parse.urlencode(args)

    # 组装初始的URL和参数，发送请求，得到返回的json
    def send_get(self, url, params):
        # 对URL添加参数
        url = self.add_query(url, params)
        # 有了这个opener之后，我们就可以用它来打开/读取 url。整个过程都在opener.open(url)
        # 这个函数中接受三个参数：fullurl，data，timeout。
        # fullurl其实有两种形式：一种是url，另一种是Request对象。
        # 经过httplib处理完成返回的Response对象有点像一个文件对象，直接用read()
        req = urllib.request.Request(url)
        resp = self.opener.open(req)
        data = Map(json.loads(resp.read().decode('utf-8')))
        if data.errcode:
            msg = "%(errcode)d %(errmsg)s" % data
            raise Login_authError(msg)
        return data

    def send_post(self, url, params, data):
        url = self.add_query(url, params)
        req = urllib.request.Request(url)
        req.add_header('Content-Type', 'application/json; charset=utf-8')
        jsondata = json.dumps(data)
        jsondataasbytes = jsondata.encode('utf-8')  # needs to be bytes
        req.add_header('Content-Length', len(jsondataasbytes))

        resp = urllib.request.urlopen(req, jsondataasbytes)

        data = Map(json.loads(resp.read().decode('utf-8')))
        if data.errcode:
            msg = "%(errcode)d %(errmsg)s" % data
            raise Login_authError(msg)
        return data

    # 专门处理ticket 的json返回是error coed 是 0 的问题
    def ticket_send_get(self, url, params):
        url = self.add_query(url, params)
        req = urllib.request.Request(url)
        resp = self.opener.open(req)
        data = Map(json.loads(resp.read().decode('utf-8')))
        return data

    # 应用授权作用域:
    # 1.snsapi_base（不弹出授权页面，直接跳转，只能获取用户openid）
    # 2.snsapi_userinfo （弹出授权页面，可通过openid拿到昵称、性别、所在地。只要用户授权，就能获取其信息）

    # 进行认证，使用scope为”snsapi_userinfo"(用时传参 redirect_uri)
    def authorize(self, redirect_uri, scope="snsapi_base", state="Moon"):
        # 生成微信认证地址并且跳转:
        #   redirect_uri: 跳转地址
        #   scope: 微信认证方式，有`snsapi_base`跟`snsapi_userinfo`两种
        #   state: 认证成功后会原样带上此字段

        # 请求微信自己的URL链接
        url = "https://open.weixin.qq.com/connect/oauth2/authorize"

        # assert作用：
        # assert语句用来声明某个条件是真的
        # 确信某个你使用的列表中至少有一个元素
        # 当assert语句失败的时候，会引发一AssertionError
        assert scope in ["snsapi_base", "snsapi_userinfo"]
        data = dict()
        data.setdefault("appid", self.app_id)
        data.setdefault("redirect_uri", redirect_uri)
        data.setdefault("response_type", "code")
        data.setdefault("scope", scope)
        data.setdefault("state", state)
        # 要搞成&appid=blabla&redirect_uri=blabla~~~~~最后还要加个#wechat_redirect
        data = [(k, data[k]) for k in sorted(data.keys()) if data[k]]
        s = "&".join("=".join(kv) for kv in data if kv[1])
        return "{0}?{1}#wechat_redirect".format(url, s)
        # 最后返回了一个微信请求带有参数的URL  使用该方法得到的是一个第一步请求URL

    # 用户同意授权后:
    # 如果用户同意授权，页面将跳转至    redirect_uri /?code = CODE & state = STATE。
    # 若用户禁止授权，则重定向后不会带上code参数，仅会带上state参数  redirect_uri?state = STATE
    # code说明 ：
    # code作为换取access_token的票据，每次用户授权带上的code将不一样，code只能使用一次，5分钟未被使用自动过期。


    # 得到access——token(用时传参code)
    def get_access_token(self, code):
        # 请求微信自己的URL链接
        url = "https://api.weixin.qq.com/sns/oauth2/access_token"
        args = dict()
        args.setdefault("appid", self.app_id)
        args.setdefault("secret", self.app_secret)
        args.setdefault("code", code)
        args.setdefault("grant_type", "authorization_code")
        return self.send_get(url, args)

    # 正确时返回的JSON数据包如下：
    # {
    #     "access_token": "ACCESS_TOKEN",
    #     "expires_in": 7200,
    #     "refresh_token": "REFRESH_TOKEN",
    #     "openid": "OPENID",
    #     "scope": "SCOPE"
    # }
    # 错误时微信会返回JSON数据包如下（示例为Code无效错误）:
    # {"errcode": 40029, "errmsg": "invalid code"}# -*- coding: utf-8 -*-


    # 检验access——token凭证是否有效(用时传参access_token,openid)
    def check_token(self, access_token, openid):
        # 请求的微信URL链接
        url = "https://api.weixin.qq.com/sns/auth"
        args = dict()
        args.setdefault("access_token", access_token)
        args.setdefault("openid", openid)
        return self.send_get(url, args)

    # 正确的Json返回结果：
    # { "errcode":0,"errmsg":"ok"}
    # 错误时的Json返回示例：
    # { "errcode":40003,"errmsg":"invalid openid"}

    # 后面微信支付调用JS接口，需要授权缺少jsapi_ticket，需要使用access——token才行
    def get_jsapi_ticket(self, accesstoken):
        url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket"
        args = dict()
        args.setdefault("access_token", accesstoken)
        args.setdefault("type", "jsapi")
        return self.ticket_send_get(url, args)

    # 成功返回如下JSON：
    # {
    #     "errcode": 0,
    #     "errmsg": "ok",
    #     "ticket": "bxLdikRXVbTPdHSM05e5u5sUoXNKd8-41ZO3MhKoyN5OfkWITDGgnr2fwJ0m9E8NYzWKVZvdVtaUgWvsdshFKA",
    #     "expires_in": 7200
    # }

    # 重新获取access——token(用时传参refresh_token)
    def token_refresh(self, refresh_token):
        # 请求微信URL链接
        url = "https://api.weixin.qq.com/sns/oauth2/refresh_token"
        args = dict()
        args.setdefault("appid", self.app_id)
        args.setdefault("grant_type", "refresh_token")
        args.setdefault("refresh_token", refresh_token)
        return self.send_get(url, args)

    # 正确时返回的JSON数据包如下：
    # {
    #     "access_token": "ACCESS_TOKEN",
    #     "expires_in": 7200,
    #     "refresh_token": "REFRESH_TOKEN",
    #     "openid": "OPENID",
    #     "scope": "SCOPE"
    # }
    # 错误时微信会返回JSON数据包如下（示例为Code无效错误）:
    # {"errcode": 40029, "errmsg": "invalid code"}


    # 获取用户信息(用时传参access_token ,openid)
    def user_info(self, access_token, openid):
        # 请求微信URL链接
        url = "https://api.weixin.qq.com/sns/userinfo"
        args = dict()
        args.setdefault("access_token", access_token)
        args.setdefault("openid", openid)
        args.setdefault("lang", "zh_CN ")
        return self.send_get(url, args)

    # 正确时返回的JSON数据包如下：
    # {
    #     "openid": " OPENID",
    #     " nickname": NICKNAME,
    #     "sex": "1",
    #     "province": "PROVINCE"
    #                 "city":"CITY",
    #                 "country":"COUNTRY",
    #                 "headimgurl":"http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6
    #                               iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLr
    #                               hJbERQQ4eMsv84eavHiaiceqxibJxCfHe/46",
    #                 "privilege":[
    #                              "PRIVILEGE1"
    #                               "PRIVILEGE2"
    #                             ],
    #     "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
    # }
    # 错误时微信会返回JSON数据包如下（示例为openid无效）:
    # {"errcode":40003,"errmsg":" invalid openid "}

    # 门票的access_token跟 网页授权的access_token不一样
    def basic_access_token(self):
        url = "https://api.weixin.qq.com/cgi-bin/token"
        args = dict()
        args.setdefault("grant_type", "client_credential")
        args.setdefault("appid", self.app_id)
        args.setdefault("secret", self.app_secret)
        return self.send_get(url, args)

    # #正常情况下，微信会返回下述JSON数据包给公众号：
    # {"access_token":"ACCESS_TOKEN","expires_in":7200}

    def send_message(self, data):
        url = 'https://api.weixin.qq.com/cgi-bin/message/template/send'
        # 判断是否需要更新token
        wct = WeChatTicket.objects().first()
        d2 = wct.write_time
        mydelta = time_comparison(d2)
        if (mydelta >= 7200):
            bs_access_token = self.basic_access_token()
            need_access_token = bs_access_token.access_token
            ticket_data = self.get_jsapi_ticket(need_access_token)
            need_ticket = ticket_data.ticket
            wct.access_token = need_access_token
            wct.ticket = need_ticket
            wct.write_time = time.time()
            wct.save()
            access_token = need_access_token
        else:
            access_token = wct.access_token
        args = dict()
        args.setdefault("access_token", access_token)
        self.send_post(url, args, data)
