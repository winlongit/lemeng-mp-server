from app.models.WeChatTicket import WechatToken
from random import Random
import urllib.request
import xml.etree.ElementTree as ET
import json
import datetime
import hashlib
import time as systemTime
from urllib.parse import quote
from config.default import Config


class WechatTools:
        
    def arrayToXml(self, arr):
        xml = ["<xml>"]
        for k, v in arr.items():
            if v.isdigit():
                xml.append("<{0}>{1}</{0}>".format(k, v))
            else:
                xml.append("<{0}><![CDATA[{1}]]></{0}>".format(k, v))
        xml.append("</xml>")
        return "".join(xml)

    def xmlToArray(self, xml):
        """将xml转为array"""
        array_data = {}
        root = ET.fromstring(xml)
        for child in root:
            value = child.text
            array_data[child.tag] = value
        return array_data

    def getRandomStrByTime(self):
        nowTime = datetime.datetime.now().strftime("%Y%m%d%H%M%S")  # 生成当前时间
        random = Random()
        randomNum = random.randint(0, 100)  # 生成的随机整数n，其中0<=n<=100
        if randomNum <= 10:
            randomNum = str(0) + str(randomNum)
        uniqueNum = str(nowTime) + str(randomNum)
        return uniqueNum

    def random_str(self):
        randomlength = 16
        str = ''
        chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789'
        length = len(chars) - 1
        random = Random()
        for i in range(randomlength):
            str += chars[random.randint(0, length)]
        return str

    def formatBizQueryParaMap(self, paraMap, urlencode):
        """格式化参数，签名过程需要使用"""
        slist = sorted(paraMap)
        buff = []
        for k in slist:
            v = quote(paraMap[k]) if urlencode else paraMap[k]
            buff.append("{0}={1}".format(k, v))

        return "&".join(buff)

    def getSign(self, obj):
        """生成签名"""
        # 签名步骤一：按字典序排序参数,formatBizQueryParaMap已做
        str = self.formatBizQueryParaMap(obj, False)
        # 签名步骤二：在string后加入KEY
        # String = "{0}&key={1}".format(String.encode('utf-8'),KEY)
        str = "{0}&key={1}".format(str, Config.KEY)
        # 签名步骤三：MD5加密
        str = hashlib.md5(str.encode('utf-8')).hexdigest()
        # 签名步骤四：所有字符转为大写
        result_ = str.upper()
        return result_

    def getSignWithoutKey(self, ticket, noncestr, timestamp, cur_url):
        data = {'jsapi_ticket': ticket, 'noncestr': noncestr, 'timestamp': timestamp, 'url': cur_url}
        sha1 = hashlib.sha1()
        keys = data.keys()
        mylist = list(data.keys())
        mylist.sort()
        data_str = '&'.join(['%s=%s' % (key, data[key]) for key in mylist])
        signature = hashlib.sha1(data_str.encode('utf-8')).hexdigest()
        return signature

    
    
    def createOauthUrlForCode(self):
        """生成可以获得code的url"""
        urlObj = {}
        urlObj["appid"] = Config.WECHAT_APPID
        urlObj["redirect_uri"] = Config.WECHAT_AUTH_URL_LOGIN
        urlObj["response_type"] = "code"
        # urlObj["scope"]             = "snsapi_base"
        urlObj["scope"] = "snsapi_userinfo"
        urlObj["state"] = "STATE#wechat_redirect"
        bizString = self.formatBizQueryParaMap(urlObj, False)
        return "https://open.weixin.qq.com/connect/oauth2/authorize?" + bizString

    def createOauthUrlForOpenid(self, code):
        """生成可以获得openid的url"""
        urlObj = {}
        urlObj["appid"] = Config.WECHAT_APPID
        urlObj["secret"] = Config.WECHAT_SECRET
        urlObj["code"] = code
        urlObj["grant_type"] = "authorization_code"
        bizString = self.formatBizQueryParaMap(urlObj, False)
        return "https://api.weixin.qq.com/sns/oauth2/access_token?" + bizString

    def getOpenIdAndNickName(self, code):
        openidUrl = self.createOauthUrlForOpenid(code)
        str_openid = urllib.request.urlopen(openidUrl).read()
        jsondata_token = json.loads(str_openid.decode())
        openid = jsondata_token['openid']
        access_token = jsondata_token['access_token']
        nickname = self.getUserInfo(access_token, openid)

        respData = {'openId': openid, 'nickname': nickname}
        return respData

    def getUserInfo(self, token, openId):
        url = "https://api.weixin.qq.com/sns/userinfo?access_token=" + token + "&openid=" + openId + "&lang=zh_CN"
        str_info = urllib.request.urlopen(url).read()
        jsondata_info = json.loads(str_info.decode())
        nickname = jsondata_info['nickname']
        sex = jsondata_info['sex']
        province = jsondata_info['province']
        city = jsondata_info['city']
        country = jsondata_info['country']
        headimgurl = jsondata_info['headimgurl']
        return nickname

    def formatBizQueryParaMap(self, paraMap, urlencode):
        """格式化参数，签名过程需要使用"""
        slist = sorted(paraMap)
        buff = []
        for k in slist:
            v = quote(paraMap[k]) if urlencode else paraMap[k]
            buff.append("{0}={1}".format(k, v))
        return "&".join(buff)

    def my_urlencode(self, str):
        reprStr = repr(str).replace(r'\x', '%')
        return reprStr[1:-1]

    def getWechatToken(self):
        url_token = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' + Config.WECHAT_APPID + '&secret=' + Config.WECHAT_SECRET
        str_token = urllib.request.urlopen(url_token).read()
        jsondata_token = json.loads(str_token.decode())
        return jsondata_token['access_token']

    def getWechatTicket(self, token):
        url_ticket = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=' + token + '&type=jsapi'
        str_ticket = urllib.request.urlopen(url_ticket).read()
        jsondata_ticket = json.loads(str_ticket.decode())
        return jsondata_ticket['ticket']

    def getWechatPayInfo(self, total_fee, openid, spbill_create_ip, Ticket, Time,QuitTime, Seq,chooseCouponId):
        jsApiObj = {}
        jsApiObj["appid"] = Config.WECHAT_APPID
        jsApiObj["mch_id"] = Config.WECHAT_MCH_ID
        jsApiObj["nonce_str"] = self.random_str()
        jsApiObj["body"] = Config.WECHAT_PAY_BODY
        jsApiObj["total_fee"] = total_fee
        jsApiObj["trade_type"] = "JSAPI"
        jsApiObj["openid"] = openid
        jsApiObj["out_trade_no"] = self.getRandomStrByTime()
        jsApiObj["spbill_create_ip"] = spbill_create_ip
        jsApiObj["notify_url"] = Config.WECHAT_PAY_NOTIFY_URL
        jsApiObj["attach"] = Config.WECHAT_PAY_ATTACH
        jsApiObj["sign"] = self.getSign(jsApiObj)
        
        # 添加微信订单存储，用于微信回调
        # Time = int(Time)
        # mWechatOrder = WechatOrder(out_trade_no = jsApiObj["out_trade_no"], sign = jsApiObj["sign"], openid = jsApiObj["openid"],Ticket = Ticket,isCheck = False, Time = Time,QuitTime = QuitTime, seq = Seq, chooseCouponId = chooseCouponId)
        # mWechatOrder.save()

        xmlRequestData = self.arrayToXml(jsApiObj)
        f = urllib.request.urlopen("https://api.mch.weixin.qq.com/pay/unifiedorder",
                                   bytes(xmlRequestData, encoding="utf8"))
        content = f.read()

        strResultXml = self.xmlToArray(content.decode())
        prepay_id = strResultXml["prepay_id"]

        retrunData = {}
        retrunData["appId"] = Config.WECHAT_APPID
        retrunData["nonceStr"] = strResultXml['nonce_str']
        retrunData["package"] = "prepay_id=" + strResultXml["prepay_id"]
        retrunData["signType"] = "MD5"
        retrunData["timeStamp"] = str(int(systemTime.time()))
        retrunData["paySign"] = self.getSign(retrunData)

        respData = {"code":1,
                    "appId": retrunData["appId"],
                    "timeStamp": retrunData["timeStamp"],
                    "nonceStr": retrunData["nonceStr"],
                    "package": retrunData["package"],
                    "signType": retrunData["signType"],
                    "paySign": retrunData["paySign"]
                    }
        return respData

    def getWechatTokenFromDB(self):
        myKey = 'token'
        mWechatToken = WechatToken.objects(key=myKey).first()
        if (mWechatToken != None):
            curTime = int(systemTime.time())
            outtime = int(mWechatToken.outtime)
            isNeedUpdate = True
            if (curTime >= outtime):  # 不需要更新
                isNeedUpdate = True
            else:  # 需要更新内容
                isNeedUpdate = False

            if (isNeedUpdate):
                gettoken = self.getWechatToken()
                getticket = self.getWechatTicket(gettoken)
                getnoncestr = self.random_str()
                sysTime = int(systemTime.time())
                getouttime = str(sysTime + 7200)
                timestamp = str(sysTime)
                mWechatToken.update(key=myKey, token=gettoken, ticket=getticket, outtime=getouttime,
                                    noncestr=getnoncestr, timestamp=timestamp)

        else:
            gettoken = self.getWechatToken()
            getticket = self.getWechatTicket(gettoken)
            getnoncestr = self.random_str()
            sysTime = int(systemTime.time())
            getouttime = str(sysTime + 7200)
            timestamp = str(sysTime)
            mWechatToken = WechatToken(key=myKey, token=gettoken, ticket=getticket, outtime=getouttime,
                                       noncestr=getnoncestr, timestamp=timestamp)
            mWechatToken.save()

        mWechatToken = WechatToken.objects(key=myKey).first()
        return mWechatToken

        
    def wechatCallback(self, return_code, out_trade_no, sign, cash_fee):
        if (return_code == "SUCCESS"):
            respData = {'return_code': "SUCCESS"}
            return respData
        else:
            respData = {'return_code': "FAIL",'return_msg':"支付失败"}
            return respData