import base64
import io


from bson.objectid import ObjectId
from flask import Flask, send_file, redirect
from flask_bower import Bower
from flask import Response

from flask_babelex import Babel
from flask_security import Security
from flask_security import utils as sec_utils
from mongoengine import GridFSProxy

from app.models import db
from app.models.CompanyAdmin import user_datastore
from app.models.Product import Product
from config import load_config
from flask_ckeditor import CKEditor

# 初始化 App
app = Flask(__name__)

config = load_config()
app.config.from_object(config)
db.init_app(app)

# 多语言支持
babel = Babel(app)

# Bower
Bower(app)

# CKEditor 富文本编辑器
CKEditor(app)

# 初始化用户
security = Security(app, user_datastore)

for name, desc in config.ROLES.items():
    user_datastore.find_or_create_role(name=name, description=desc)


@app.before_first_request
def create_user():
    if not user_datastore.find_user(username='admin'):
        hashed_password = sec_utils.encrypt_password('admin')
        user = user_datastore.create_user(username='admin', password=hashed_password)
        user_datastore.add_role_to_user(user, 'SuperAdmin')


# Flask views
# 首页
@app.route('/')
def index():
    return redirect('/task_list')


# 返回图片链接
@app.route('/img/<oid>')
def get_image(oid):
    proxy = GridFSProxy(grid_id=ObjectId(oid), collection_name='images')
    if not proxy:
        return ''

    return Response(proxy.read(),
                    content_type=proxy.content_type,
                    headers={
                        'Content-Length': proxy.length
                    })


# 返回图片链接
@app.route('/pdf/<oid>')
def get_pdf(oid):
    proxy = GridFSProxy(grid_id=ObjectId(oid), collection_name='fs')
    if not proxy:
        return ''

    return Response(proxy.read(),
                    content_type=proxy.content_type,
                    headers={
                        'Content-Length': proxy.length
                    })


@app.route('/img/')
def get_blank():
    gif = 'R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=='
    gif_str = base64.b64decode(gif)
    return send_file(io.BytesIO(gif_str), mimetype='image/gif')


# 整合各个route页面
from flask.blueprints import Blueprint
from app import routes


def _import_submodules_from_package(package):
    import pkgutil

    modules = []
    for importer, modname, ispkg in pkgutil.iter_modules(package.__path__,
                                                         prefix=package.__name__ + "."):
        modules.append(__import__(modname, fromlist="dummy"))
    return modules


for module in _import_submodules_from_package(routes):
    bp = getattr(module, 'bp')
    if bp and isinstance(bp, Blueprint):
        app.register_blueprint(bp)

# 后台管理的页面整合
from app.views.AdminIndexView import *


# define a context processor for merging flask-admin's template context into the
# flask-security views.
@security.context_processor
def security_context_processor():
    return dict(
        admin_base_template=adminView.base_template,
        admin_view=adminView.index_view,
        h=admin_helpers,
        get_url=url_for
    )


if __name__ == '__main__':
    app.run(debug=True)
