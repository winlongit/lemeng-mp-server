/**
 * Created by tanyanqing1 on 16/3/16.
 */


function GetQueryString(name)
{
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
}

function GetWechatOpenID ()
{
     return window.localStorage.getItem("wechatOpenId");
}
function SetWechatOpenID (myOpenID)
{
     window.localStorage.setItem("wechatOpenId", myOpenID);
}

function GetWechatNickname ()
{
     return window.localStorage.getItem("wechatNickname");
}
function SetWechatNickname (myNickname)
{
     window.localStorage.setItem("wechatNickname", myNickname);
}