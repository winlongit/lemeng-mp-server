/**
 * Created by tanyanqing1 on 16/3/14.
 */


var my_html_title   = '中扑社区'
var my_ip_address   = 'http://192.168.1.153:5000';
var RESULT_SUCCESS  = 1;
var RESULT_ERROR    = 0;

var my_wechat_appid     = 'wx5dd4b8854b6c7976';