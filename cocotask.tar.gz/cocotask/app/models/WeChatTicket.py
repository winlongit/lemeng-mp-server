from . import db
import datetime


# 微信的基础access_token(不是网页授权得到的access_token)，获取 ticket必须的。
# 微信的ticket ，配置JS接口必须的。
# write_time 用这个和现在时间做对比，如果秒数>7200秒（微信是7200)，就更新access_token 否则就不用更新
class WeChatTicket(db.Document):
    name = db.StringField(max_length=255 ,verbose_name='请勿更改')
    access_token = db.StringField(max_length=255 ,verbose_name='token')
    ticket = db.StringField(max_length=255 , verbose_name='票据')
    write_time = db.IntField(verbose_name='使用开始时间')
    def __unicode__(self):
        return str(self.name)
