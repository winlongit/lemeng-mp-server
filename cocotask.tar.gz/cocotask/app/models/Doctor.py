from . import db
import datetime


# 用户管理model
class Doctor(db.Document):
    tel = db.StringField(verbose_name='手机')
    openid = db.StringField(verbose_name='微信号')
    name = db.StringField(verbose_name='姓名')
    sex = db.StringField(verbose_name='性别')
    zj_type = db.StringField(verbose_name='证件类型')
    zj_code = db.StringField(verbose_name='证件号码')
    city = db.StringField(verbose_name='城市')
    yy = db.StringField(verbose_name='医院')
    ks = db.StringField(verbose_name='科室')
    zc = db.StringField(verbose_name='职称')
    up_type = db.StringField(verbose_name='上传类别')
    up_0 = db.StringField(verbose_name='上传图片1')
    up_1 = db.StringField(verbose_name='上传图片2')
    rz_status = db.IntField(verbose_name='认证状态')
    is_mr = db.IntField(verbose_name='是否管理员')
    credit = db.IntField(verbose_name='积分', default=0)
    create_time = db.DateTimeField(default=datetime.datetime.now, verbose_name='创建时间')

    def __unicode__(self):
        return str(self.wechat_openid)
