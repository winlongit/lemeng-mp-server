from . import db
import datetime

class Log(db.Document):
    type = db.StringField(max_length=255)
    level = db.IntField()  # 日志层级
    content = db.StringField()  # 日志内容
    operator = db.StringField(max_length=255)  # 操作员
    create_time = db.DateTimeField(default=datetime.datetime.now)  # 创建时间
    create_place = db.StringField(max_length=255)  # 创建地点
    note = db.StringField()  # 其他备注
    meta = {'allow_inheritance': True}