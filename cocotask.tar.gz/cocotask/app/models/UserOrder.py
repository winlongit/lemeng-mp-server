import datetime

from . import db


# 订单管理model
class UserOrder(db.Document):
    openid = db.StringField(max_length=255, verbose_name='微信openid')

    out_trade_no = db.StringField(max_length=255, verbose_name='商户订单号')
    body = db.StringField(max_length=255, verbose_name='商品简单描述')
    total_fee = db.FloatField(verbose_name='订单总金额')
    ischeck = db.StringField(max_length=255, verbose_name='支付状态')  # 已支付，未支付
    status = db.StringField(max_length=255, verbose_name='当前订单状态')  # 支付中，，支付成功，支付失败
    create_time = db.DateTimeField(default=datetime.datetime.now, verbose_name='创建时间')

    def __unicode__(self):
        return str(self.out_trade_no)
