from . import db
import datetime


# 检测结果
class Result(db.DynamicDocument):
    prod_name = db.StringField(max_length=255, verbose_name='产品名称')  # 检测产品名称
    hospital = db.StringField(max_length=255, verbose_name='医院名称')
    department = db.StringField(max_length=255, verbose_name='部门名称')  # 检测部门名称
    name = db.StringField(max_length=255, verbose_name='姓名')
    sex = db.StringField(max_length=255, verbose_name='性别')
    age = db.StringField(max_length=255, verbose_name='年龄')
    sent_hospital = db.StringField(max_length=255, verbose_name='送检医院')
    sent_doctor = db.StringField(max_length=255, verbose_name='送检医师')
    outpatient_no = db.StringField(max_length=255, verbose_name='门诊号')
    result = db.StringField(max_length=255, verbose_name='临床诊断')
    sample_no = db.StringField(max_length=255, verbose_name='标本编号')
    sample_type = db.StringField(max_length=255, verbose_name='标本类型')
    sample_status = db.StringField(max_length=255, verbose_name='样本状态')

    method = db.StringField(verbose_name='检测方法')
    result_detail = db.StringField(verbose_name='检测详细结果')
    result_desc = db.StringField(verbose_name='结果描述')
    note = db.StringField(verbose_name='备注')

    operator = db.StringField(max_length=255, verbose_name='检验者')
    auditor = db.StringField(max_length=255, verbose_name='审核者')

    create_time = db.DateTimeField(default=datetime.datetime.now, verbose_name='创建时间')

    # 默认返回结果数据
    def __unicode__(self):
        return str(self.result)
