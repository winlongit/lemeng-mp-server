from flask_security import MongoEngineUserDatastore, UserMixin, RoleMixin
from . import db

import datetime
from mongoengine.queryset.base import CASCADE


# Role
class Role(db.Document, RoleMixin):
    name = db.StringField(max_length=80, unique=True, verbose_name='名称')
    description = db.StringField(max_length=255)

    def __str__(self):
        return self.description

    def __unicode__(self):
        return self.description


# 管理员管理model
class CompanyAdmin(db.Document, UserMixin):
    username = db.StringField(verbose_name="Name", max_length=255, required=True, unique=True)
    password = db.StringField(max_length=255)
    email = db.EmailField(max_length=255)
    telephone = db.StringField(max_length=50)
    create_time = db.DateTimeField(default=datetime.datetime.now)
    roles = db.ListField(db.ReferenceField(Role), default=[])
    active = db.BooleanField(default=True)

    def __unicode__(self):
        return str(self.username)


user_datastore = MongoEngineUserDatastore(db, CompanyAdmin, Role)
