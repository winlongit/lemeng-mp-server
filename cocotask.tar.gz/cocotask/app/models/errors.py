# -*- coding: UTF-8 -*-

# 错误信息提示：
CODE_NOT_FOUND = [20003, 404, '系统小故障未能得到code，抱歉请重新尝试~']
OPENID_NOT_FOUND = [20004, 404, '系统小故障未能得到id，抱歉请重新尝试~']
ATOKEN_NOT_FOUND = [20008, 404, '系统小故障未能得到token，抱歉请重新尝试~']
OPENID_NOT_PASS = [20005, 404, '请您先授权，再选择服务谢谢~']
ORDER_NOT_FOUND = [20006, 404, '系统故障，未能正确下单，如有疑问请联系我们~我们将配合您解决问题']
SUPER_NOT_FOUND = [20007, 404, '提示：您不是超级管理员~']
LONG_TIME_WAIT = [20009, 404, '提示：长时间未操作，请关闭当前页面，重新选择']
BODY_AND_FEE_NOT_FOUND = [200010, 404, '提示：系统故障，请您重新选择产品，抱歉']
PHONE_NO_ORDER = [200011, 404, '抱歉：该手机号查询不到订单，请您按提示操作']
NO_TICKET = [20012, 404, 'ticket有错误，请重新尝试']
NO_CONFIG_TICKET_DICT = [20013, 404, 'JS接口配置错误，请重新尝试']
NO_MONGO = [20014, 404, '数据库没找到数据']
XML_NOT_FOUND = [20015, 404, 'xml数据没得到']
NOT_AUTHORIZED = [20016, 404, '您未授权查看该订单']
RESULT_NOT_FOUND = [20017, 404, '结果还没出来']
PROJECT_NOT_FOUND = [20018, 404, '系统故障，未能找到项目，如有疑问请联系我们~我们将配合您解决问题']
