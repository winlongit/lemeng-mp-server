from . import db
import datetime


# 用户管理model
class Task(db.Document):
    name = db.StringField(max_length=255, verbose_name='任务名称')
    type = db.StringField(max_length=255, verbose_name='任务类型')
    list_image = db.ImageField(verbose_name='列表配图')
    desc = db.StringField(max_length=255, verbose_name='任务描述')
    content = db.StringField(verbose_name='任务内容')
    status = db.StringField(max_length=255, verbose_name='任务状态')
    creator = db.StringField(max_length=255, verbose_name='创建人')
    create_time = db.DateTimeField(default=datetime.datetime.now, verbose_name='创建时间')
    meta = {'allow_inheritance': True}

    def __unicode__(self):
        return str(self.name)

    def get_list_image(self):
        obj = self.list_image
        if not obj.grid_id:
            return ''
        return "/img/%s" % (str(obj.grid_id))


class RaidTask(Task):
    perioud = db.IntField(verbose_name='周期')
    holiday = db.IntField(verbose_name='假期')
    deposit = db.FloatField(verbose_name='押金')
    joined = db.IntField(verbose_name='参加人数')