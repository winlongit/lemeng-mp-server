from . import db
from app.models.Task import Task
import datetime


# 用户管理model
class User(db.Document):
    wechat_openid = db.StringField(max_length=255, verbose_name='用户openid')
    name = db.StringField(max_length=255, verbose_name='用户名称')
    nickname = db.StringField(max_length=255, verbose_name='用户昵称')
    phone = db.StringField(max_length=50, verbose_name='电话号码')
    province = db.StringField(max_length=255, verbose_name='省')
    city = db.StringField(max_length=255, verbose_name='市')
    area = db.StringField(max_length=255, verbose_name='区')
    address = db.StringField(max_length=255, verbose_name='详细地址')
    task_list = db.DictField(verbose_name='任务列表')

    create_time = db.DateTimeField(default=datetime.datetime.now, verbose_name='创建时间')

    def __unicode__(self):
        return str(self.wechat_openid)
