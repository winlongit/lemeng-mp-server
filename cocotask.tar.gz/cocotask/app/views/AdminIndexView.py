import flask_admin as admin
import flask_admin.consts
from flask import render_template, url_for
from flask_admin import expose
from flask_admin import helpers as admin_helpers
from flask_security import login_required

from app import app, config
from app.views.CompanyAdminView import CompanyAdminView
from app.views.RaidTaskView import RaidTaskView
from app.views.UserView import UserView
from app.views.UserOrderView import UserOrderView


class AdminIndexView(admin.AdminIndexView):
    @expose('/')
    @login_required
    def index(self):
        return render_template('myadmin/index.html', admin_view=self, get_url=url_for, h=admin_helpers, )


# Create admin
adminView = flask_admin.Admin(app,
                              config.SITE_TITLE,
                              index_view=AdminIndexView(),
                              base_template='myadmin/index.html',
                              template_mode='bootstrap3',
                              )

adminView.add_view(CompanyAdminView('管理员',
                                    menu_icon_type=flask_admin.consts.ICON_TYPE_FONT_AWESOME,
                                    menu_icon_value='fa fa-user-md fa-fw',
                                    roles_accepted=['SuperAdmin', ]
                                    ))

adminView.add_view(RaidTaskView('团队任务管理',
                                 menu_icon_type=flask_admin.consts.ICON_TYPE_FONT_AWESOME,
                                 menu_icon_value='fa fa-user fa-fw',
                                 ))

adminView.add_view(UserView('用户管理',
                            menu_icon_type=flask_admin.consts.ICON_TYPE_FONT_AWESOME,
                            menu_icon_value='fa fa-user fa-fw',
                            ))

adminView.add_view(UserOrderView('订单管理',
                            menu_icon_type=flask_admin.consts.ICON_TYPE_FONT_AWESOME,
                            menu_icon_value='fa fa-user fa-fw',
                            ))