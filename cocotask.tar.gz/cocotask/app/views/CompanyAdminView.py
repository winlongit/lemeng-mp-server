from wtforms import validators
from wtforms.fields import PasswordField
from wtforms.fields import PasswordField, SelectField
from flask_security import utils
from app.models.CompanyAdmin import CompanyAdmin
from .CustomView import CustomView


# 管理员管理界面的定义
class CompanyAdminView(CustomView):
    def __init__(self, session, **kwargs):
        self.model_not_can_edit = False
        self.column_default_sort = ("create_time", True)
        self.column_exclude_list = ('password', 'active')
        self.column_labels = dict(username='用户名',
                                  telephone='联系电话',
                                  roles='管理员等级',
                                  email='电子邮箱',
                                  create_time='创建时间',
                                  active='状态',
                                  name='名字',
                                  )

        self.form_columns = (
            'username', 'password2', 'password_new',
            'email', 'telephone', 'roles', 'create_time')

        password2 = PasswordField('密码', [validators.DataRequired()])
        password_new = PasswordField('新密码')
        self.form_extra_fields = {
            'password2': password2,
            'password_new': password_new,
        }

        self.form_widget_args = {
            'password2': {
                'autocomplete': 'new-password'
            },
            'password_new': {
                'autocomplete': 'new-password'
            }
        }

        self.form_args = dict(
            username=dict(label='名称'),
            password2=dict(label='密码'),
            password_new=dict(label='新密码'),
            email=dict(label='电子邮箱'),
            telephone=dict(label='联系电话'),
            roles=dict(label='管理员等级'),
            create_time=dict(label='创建时间')
        )

        self.form_create_rules = ('username', 'password2', 'email', 'telephone', 'roles', 'create_time')
        self.form_edit_rules = ('username', 'password_new', 'email', 'telephone', 'roles', 'create_time')

        super(CompanyAdminView, self).__init__(CompanyAdmin, session, **kwargs)

    def on_model_change(self, form, model, is_created):
        if is_created == False:
            if len(form.password_new.data):
                p = form.password_new.data.encode('utf-8')
                model.password = utils.encrypt_password(p)
        else:
            if len(form.password2.data):
                p = form.password2.data.encode('utf-8')
                model.password = utils.encrypt_password(p)
