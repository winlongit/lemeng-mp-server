from app.models.UserOrder import UserOrder
from .CustomView import CustomView


class UserOrderView(CustomView):
    can_view_details = True
    can_edit = True
    can_export = True
    can_create = True

    def __init__(self, session, **kwargs):
        self.column_default_sort = ('create_time', True)
        super(UserOrderView, self).__init__(UserOrder, session, **kwargs)
