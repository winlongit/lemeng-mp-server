from .CustomView import CustomView
from app.models.Product import Product
from flask_admin.contrib.mongoengine import ModelView
from jinja2 import Markup
from wtforms import SelectField
from flask_admin.form import Select2Field
from .CustomView import CustomView, CKTextAreaField


def list_thumbnail(view, context, model, name):
    if model.picture:
        return Markup('<img src="/admin/product/api/file/?id=%s&coll=images" height="32">' % model.picture._id)
    else:
        return ''


class ProductView(CustomView):
    def __init__(self, session, **kwargs):
        self.extra_js = ['../../../static/ckeditor/ckeditor.js']
        self.can_view_details = True
        self.column_default_sort = ('create_time', True)
        self.column_labels = dict(name='商品名称',
                                  price='价格',
                                  list_pic='列表图片',
                                  type='产品分类',
                                  test_type='检测方式',
                                  post_type='配送方式',
                                  list_desc='产品描述',
                                  desc_pic='产品大图',
                                  desc_detail='产品简介',
                                  desc_content='检测内容',
                                  desc_note='注意事项',
                                  note='商品备注',
                                  create_time='创建时间',
                                  hide='隐藏'
                                  )
        self.column_list = ('list_pic', 'name', 'price', 'type', 'post_type', 'list_desc', 'create_time', 'hide')
        self.column_formatters = {
            'picture': list_thumbnail
        }

        self.form_overrides = {
            'post_type': Select2Field,
            'test_type': Select2Field,
            'type': Select2Field,
            'known_issues': CKTextAreaField,
            'known_issues_patient': CKTextAreaField,
            'send_note': CKTextAreaField
        }

        self.form_args = dict(
            test_type=dict(choices=[
                ('口腔拭子', '口腔拭子'),
                ('全血', '全血'),
                ('组织样本', '组织样本'),
                ('口腔唾液', '口腔唾液')]
            ),
            post_type=dict(choices=[
                ('邮寄', '邮寄'),
                ('送检', '送检')]
            ),
            type=dict(choices=[
                ('产前基因筛查', '产前基因筛查'),
                ('生殖健康', '生殖健康')]
            )
        )

        self.column_formatters = dict(
            list_pic=lambda u, v, m, p: self.getImageHtml(m, p, 100, 100),
            desc_pic=lambda u, v, m, p: self.getImageHtml(m, p, 800),
            desc_detail=lambda u, v, m, p: self.getImageHtml(m, p, 800),
            desc_content=lambda u, v, m, p: self.getImageHtml(m, p, 800),
            desc_note=lambda u, v, m, p: self.getImageHtml(m, p, 800)
        )

        super(ProductView, self).__init__(Product, session, **kwargs)

    def getImageHtml(self, product, field, width='auto', height='auto'):
        obj = eval('product.' + field)
        if not obj.grid_id:
            return ''
        return Markup('<img src="/img/%s" width="%s" height="%s" />' % (str(obj.grid_id), width, height))
