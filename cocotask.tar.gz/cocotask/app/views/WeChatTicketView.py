from app.models.WeChatTicket import WeChatTicket
from .CustomView import CustomView

class WeChatTicketView(CustomView):
    def __init__(self, session, **kwargs):
        self.column_default_sort = ('write_time', True)
        self.column_labels = dict(name='请勿修改',
                                  access_token='令牌',
                                  ticket='票据',
                                  write_time='最初有效时间'
                                  )
        super(WeChatTicketView, self).__init__(WeChatTicket, session, **kwargs)