from datetime import date

from flask import redirect
from flask_admin.contrib.mongoengine import ModelView
from flask_security import current_user, url_for_security
from flask_admin.model import typefmt
from jinja2 import Markup
from wtforms import TextAreaField
from wtforms.widgets import TextArea


class CKTextAreaWidget(TextArea):
    def __call__(self, field, **kwargs):
        if kwargs.get('class'):
            kwargs['class'] += ' ckeditor'
        else:
            kwargs.setdefault('class', 'ckeditor')
        return super(CKTextAreaWidget, self).__call__(field, **kwargs)


class CKTextAreaField(TextAreaField):
    widget = CKTextAreaWidget()


def date_format(view, value):
    return value.strftime('%Y.%m.%d %H:%M:%S')


MY_DEFAULT_FORMATTERS = dict(typefmt.BASE_FORMATTERS)
MY_DEFAULT_FORMATTERS.update({
    date: date_format
})
MY_DEFAULT_FORMATTERS_EXPORT = dict(typefmt.EXPORT_FORMATTERS)
MY_DEFAULT_FORMATTERS_EXPORT.update({
    date: date_format
})


# 将秒转换成时分秒格式
def format_seconds_to_hhmmss(seconds):
    if seconds != None:
        hours = seconds // (60 * 60)
        seconds %= (60 * 60)
        minutes = seconds // 60
        seconds %= 60
        return "%i:%02i:%02i" % (hours, minutes, seconds)
    return "%i:%02i:%02i" % (0, 0, 0)


def is_accessible(roles_accepted=None, user=None):
    if user.has_role('SuperAdmin'):
        return True
    if roles_accepted == ['ALL']:
        return True
    if roles_accepted:
        accessible = any(
            [user.has_role(role) for role in roles_accepted]
        )
        return accessible
    return False


class CustomView(ModelView):
    column_type_formatters = MY_DEFAULT_FORMATTERS
    column_type_formatters_export = MY_DEFAULT_FORMATTERS_EXPORT

    def __init__(self, *args, **kwargs):
        self.roles_accepted = kwargs.pop('roles_accepted', list())
        super(CustomView, self).__init__(*args, **kwargs)

    def is_accessible(self):
        roles_accepted = getattr(self, 'roles_accepted', None)
        accessible = is_accessible(roles_accepted=roles_accepted, user=current_user)

        if current_user.has_role('SuperAdmin'):
            self.can_delete = True
        else:
            self.can_delete = False

        return accessible

    def _handle_view(self, name, *args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for_security('login', next="/admin"))
        if not self.is_accessible():
            # return self.render("admin/denied.html")
            return "<p>Access denied</p>"

    def _list_thumbnail(self, view, context, model, name):
        if not model.logo.thumbnail:
            return ''

        return Markup('<img src="/img/%s">' % str(model.logo.thumbnail._id))
