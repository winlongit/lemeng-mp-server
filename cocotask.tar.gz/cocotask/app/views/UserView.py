from app.models.User import User
from .CustomView import CustomView
from flask_admin.contrib.mongoengine import ModelView


# 用户管理界面的定义
class UserView(CustomView):
    can_view_details = True

    def __init__(self, session, **kwargs):
        self.column_list = (
            'wechat_openid', 'name', 'phone', 'address', 'create_time', 'info', 'referee')
        self.column_default_sort = ("create_time", True)
        self.column_labels = dict(
            wechat_openid='微信ID',
            name='姓名',
            phone='移动电话',
            address='地址',
            create_time='创建时间'
        )
        self.form_args = dict(
            wechat_openid=dict(label='微信ID'),
            name=dict(label='姓名'),
            phone=dict(label='移动电话'),
            address=dict(label='地址'),
            create_time=dict(label='创建时间')
        )
        self.column_searchable_list = (
            'wechat_openid', 'name', 'address', 'phone')

        self.column_details_exclude_list = ('varify_code')
        super(UserView, self).__init__(User, session, **kwargs)
