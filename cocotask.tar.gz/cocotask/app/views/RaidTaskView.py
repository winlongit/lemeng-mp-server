from jinja2 import Markup

from app.models.Task import RaidTask
from .CustomView import CustomView
from flask_admin.form import Select2Field
from flask_ckeditor import CKEditorField

def list_thumbnail(view, context, model, name):
    if model.list_image:
        return Markup('<img src="/admin/raidtask/api/file/?id=%s&coll=images" height="32">' % model.picture._id)
    else:
        return ''

class RaidTaskView(CustomView):
    def __init__(self, session, **kwargs):
        self.extra_js = ['//cdn.ckeditor.com/4.6.0/standard/ckeditor.js']
        self.can_view_details = True
        self.column_default_sort = ('create_time', True)
        self.form_overrides = {
            'type': Select2Field,
           # 'content': CKEditorField
        }

        self.form_args = dict(
            type=dict(choices=[
                ('团队任务', '团队任务'),
            ]
            ),
        )

        self.column_formatters = dict(
            list_image=lambda u, v, m, p: self.getImageHtml(m, p, 200, 133),
        )

        super(RaidTaskView, self).__init__(RaidTask, session, **kwargs)


    def getImageHtml(self, RaidTask, field, width='auto', height='auto'):
        obj = eval('RaidTask.' + field)
        if not obj.grid_id:
            return ''
        return Markup('<img src="/img/%s" width="%s" height="%s" />' % (str(obj.grid_id), width, height))